/*dom*/

const bt1=document.querySelector('#yone')
const bt2=document.querySelector('#yoneemi')
const bt3=document.querySelector('#yonevelho')

/*events*/

bt1.addEventListener('click', yone)
bt2.addEventListener('click', yoneemi)
bt3.addEventListener('click',yonevelho)

/*função*/

function yone(){
    yoneimg.src='imagens/yone.jpg'
}

function yoneemi(){
    yoneimg.src='imagens/yoneemissario.jpg'
}

function yonevelho (){
    yoneimg.src='imagens/yonevo.jpg'
}
