const bt1=document.querySelector('#fragmentado')
const bt2=document.querySelector('#origem')
const bt3=document.querySelector('#conjunring')
const bt4=document.querySelector('#ultimato')
const text = document.querySelector('#text')
const foto = document.querySelector('#semfoto')
/*events*/

bt1.addEventListener('click',()=>{

    semfoto.src = 'images/fragmentado.jpg'

    text.innerHTML = 'Kevin possui 23 personalidades distintas e consegue alterná-las quimicamente em seu organismo apenas com a força do pensamento. Um dia, ele sequestra três adolescentes que encontra em um estacionamento. Vivendo em cativeiro, elas passam a conhecer as diferentes facetas de Kevin e precisam encontrar algum meio de escapar.'
})

bt2.addEventListener('click',()=>{

    semfoto.src = 'images/a origem.jpg'

    text.innerHTML = 'Dom Cobb é um ladrão com a rara habilidade de roubar segredos do inconsciente, obtidos durante o estado de sono. Impedido de retornar para sua família, ele recebe a oportunidade de se redimir ao realizar uma tarefa aparentemente impossível: plantar uma ideia na mente do herdeiro de um império. Para realizar o crime perfeito, ele conta com a ajuda do parceiro Arthur, o discreto Eames e a arquiteta de sonhos Ariadne. Juntos, eles correm para que o inimigo não antecipe seus passos.'
})

bt3.addEventListener('click',()=>{

    semfoto.src = 'images/conjunring.jpeg'

    text.innerHTML = 'Os famosos demonologistas Lorraine e Ed Warren viajam até o norte de Londres. Lá, eles ajudam uma mãe solteira que cria quatro filhos sozinha em uma casa atormentada por espíritos malignos.'
})

bt4.addEventListener('click',()=>{

    semfoto.src = 'images/ultimato.jpg'

    text.innerHTML = 'Após Thanos eliminar metade das criaturas vivas, os Vingadores têm de lidar com a perda de amigos e entes queridos. Com Tony Stark vagando perdido no espaço sem água e comida, Steve Rogers e Natasha Romanov lideram a resistência contra o titã louco.'
})



