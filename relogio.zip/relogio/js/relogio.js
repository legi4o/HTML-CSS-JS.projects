//dom

const horas = document.querySelector('#horas')
const minutos = document.querySelector('#minutos')
const segundos = document.querySelector('#segundos')
const dial = document.querySelector('#dia')
const mes = document.querySelector('#mes')
const ano = document.querySelector('#ano')
const texto = document.querySelector('#texto')
//eventos

setInterval(relogio, 1000)

//função

function relogio() {

    let dia = new Date()
    let h = dia.getHours()
    let m = dia.getMinutes()
    let s = dia.getSeconds()
    let diaa = dia.getDate()
    let mm = dia.getMonth()
    let aa = dia.getFullYear()

    if (h < 10) {
        h = "0" + h
    }

    if (m < 10) {
        m = "0" + m
    }

    if (s < 10) {
        s = "0" + s
    }
    
    
    if (diaa < 10) {
        diaa = "0" + diaa
    }
    if (mm < 10) {
        mm = "0" + mm
    }

    if (h > 4 && h < 12) {
        texto.textContent = 'Bom Dia!'

    }else if (h > 1 && h < 18) {
        texto.textContent = 'Boa Tarde!'

    }else if (h > 17 && h < 0) {
        texto.textContent = 'Boa Noite!'
    }

    horas.textContent = h
    minutos.textContent = m
    segundos.textContent = s
    dial.textContent = diaa
    mes.textContent = mm
    ano.textContent = aa

}

