//dom

const distancia = document.querySelector('#d')
const consumo = document.querySelector('#consumo')
const preco = document.querySelector('#p')
const calcular = document.querySelector('#calcular')
const resultado = document.querySelector('#resultado')

//events

calcular.addEventListener('click',()=>{

dis = Number(distancia.value)
con = Number(consumo.value)
pre = Number(preco.value)

viagem = (dis/con)*pre

resultado.textContent = `O valor gasto parta essa viagem sera de R$ ${viagem.toFixed(2)}`

})